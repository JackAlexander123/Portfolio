<?php 

function json_response($message = null, $code = 200, $images = null){
  // clear the old headers
  header_remove();
  // set the actual code
  http_response_code($code);
  // set the header to make sure cache is forced
  header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
  // treat this as json
  header('Content-Type: application/json');
  $status = array(
    200 => '200 OK',
    400 => '400 Bad Request',
    422 => 'Unprocessable Entity',
    500 => '500 Internal Server Error'
    );
  // ok, validation error, or failure
  header('Status: '.$status[$code]);
  // return the encoded json
  return json_encode(array(
    'status' => $code < 300, // success or not?
    'message' => $message,
    'image' => $images
    ));
}

$no_file_name = "Please set a file name!";

$file_name = $_POST['file_name'];

if (empty($file_name)) {
  header('Content-Type: application/json');
  echo json_response($no_file_name, 422);
}else{
  $file_location = '\\\GRIFFIN\email_creatives_share/link-replacer/' . $_POST['file_name'] . '.html';

  $message = 'Thank you for your submission!';

  $html = file_get_contents($file_location);
  //Create a new DOM document
  $dom = new DOMDocument;

  $split_links = array();
  $split_images = array();
  $linkcount = 0;

  //Parse the HTML. The @ is used to suppress any parsing errors
  //that will be thrown if the $html string isn't valid XHTML.
  @$dom->loadHTML($html);

  //Get all links. You could also use any other tag name here,
  //like 'img' or 'table', to extract other tags.
  $links = $dom->getElementsByTagName('a');
  $images = $dom->getElementsByTagName('img');

  //Get all images. You could also use any other tag name here,
  //like 'img' or 'table', to extract other tags.
  // $images = $dom->getElementsByTagName('img');

  //Iterate over the extracted links and display their URLs
  foreach ($links as $link){
      //Extract and show the "href" attribute.
      $link_text = $link->nodeValue;
      $link_value = $link->getAttribute('href');
      $link_image = $link->c14n();


      $image_src = preg_match("/src=\"([^\"]*)\"/", $link_image, $output_array);
      $output_array = preg_replace("/(img\.*)/", "https://griffin.gnm.office/flexshare/email_creatives_share/link-replacer/img/" . $image_src, $output_array);
      $output_array = preg_replace("/(img\/.*\/)/", "img/", $output_array);


      $split_links[] = array(
        'text'  => $link_text,
        'value' => $link_value,
        'image_array' => $output_array,
        // 'image' => $image,
        // 'image' => $image_src,
      );
  }

  foreach($images as $image)
  {
    if($image->parentNode->nodeName === 'a')
    {
      $sImgValue = $image->getAttribute('src');
      $sLinkValue = $image->parentNode->getAttribute('href');

      $split_images[] = array(
        'image'      => $image_src,
        'image_link' => $sLinkValue,
      );
    }
  }

  $full_link_info = $split_links;
  $full_img_info  = $split_images;

  header('Content-Type: application/json;');
  echo json_response($full_link_info, 200, $split_images);
}


?>