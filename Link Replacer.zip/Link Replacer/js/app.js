$(document).foundation();
$(document).ready(function () { 
	$('#run-scan').on('click', function(e) {
		$('.link-wrapper').remove();
		$('.success-block').removeClass('in');
		$('.fail-block').removeClass('in');
		$('.loading-block').addClass('in');
		e.preventDefault();
		console.log('test()!');
    var theName = $('#name_of_file').val();
		$.ajax({
			url: 'post.php',
			method: 'POST',
			dataType: 'json',
			data: {
				file_name: theName
			},
			beforeSend: (function(){
				console.log('beforeSend()!');
			})
		})
		.done(function( xhr ){
			console.log('done()!');
			console.log(xhr);
			$.each( xhr['message'], function( i, val ) {
				if (val['text'] === "") {
				  $( '#result' ).append('<div class="link-wrapper"><div class="small-12 medium-4 columns">Text or Image linked:<br><img src="' + val['image_array'][1] + '"></div><div class="small-12 medium-4 columns">Raw link:<br> ' + val['value'] + '</div><div class="small-12 medium-4 columns"><input type="text" class="new-link" id="marketing-town-link-' + i + '"></div></div>'  );
				}else{
				  $( '#result' ).append('<div class="link-wrapper"><div class="small-12 medium-4 columns">Text or Image linked:<br> ' + val['text'] + '</div><div class="small-12 medium-4 columns">Raw link:<br> ' + val['value'] + '</div><div class="small-12 medium-4 columns"><input type="text" class="new-link" id="marketing-town-link-' + i + '"></div></div>'  );
				}
			});
			$('.loading-block').removeClass('in');
			$('.success-block').addClass('in');
		})
		.fail(function( xhr ){
			console.log('fail()!');
			$('.loading-block').removeClass('in');
			$('.fail-block').addClass('in');
			console.log(xhr.responseText);
			$('#error').children('.alert-box').text(xhr.responseText['message']);
		});
		return false;
	});

	$('#change-links').on('click', function(e) {
		e.preventDefault();
		$('.success-block').removeClass('in');
		$('.fail-block').removeClass('in');
		$('.loading-block').addClass('in');
		console.log('test()!');
    var theName = $('#name_of_file').val();
		var link_array = new Array();
		$.each( $('.new-link'), function() {
		  link_array.push($(this).val());
		});
		$.ajax({
			url: 'change-the-links.php',
			method: 'POST',
			dataType: 'json',
			data: {
				new_links: link_array,
				file_name: theName
			},
			beforeSend: (function(){
				console.log('beforeSend()!');
				console.log(link_array);
			})
		})
		.done(function( xhr ){
			$.ajax({
				url: 'post.php',
				method: 'POST',
				dataType: 'json',
				data: {
					file_name: theName
				},
				beforeSend: (function(){
					console.log('beforeSend()!');
				})
			})
			.done(function( xhr ){
				$('.link-wrapper').remove();
				console.log('done()!');
				console.log(xhr);
				$.each( xhr['message'], function( i, val ) {
					if (val['text'] === "") {
					  $( '#result' ).append('<div class="link-wrapper"><div class="small-12 medium-4 columns">Text or Image linked:<br><img src="' + val['image_array'][1] + '"></div><div class="small-12 medium-4 columns">Raw link:<br> ' + val['value'] + '</div><div class="small-12 medium-4 columns"><input type="text" class="new-link" id="marketing-town-link-' + i + '"></div></div>'  );
					}else{
					  $( '#result' ).append('<div class="link-wrapper"><div class="small-12 medium-4 columns">Text or Image linked:<br> ' + val['text'] + '</div><div class="small-12 medium-4 columns">Raw link:<br> ' + val['value'] + '</div><div class="small-12 medium-4 columns"><input type="text" class="new-link" id="marketing-town-link-' + i + '"></div></div>'  );
					}
				});
				$('.loading-block').removeClass('in');
				$('.success-block').addClass('in');
			})
			console.log('done()!');
			console.log(xhr);
			$('.loading-block').removeClass('in');
			$('.success-block').addClass('in');
		})
		.fail(function( xhr ){
			console.log('fail()!');
			console.log(xhr);
			$('.loading-block').removeClass('in');
			$('.fail-block').addClass('in');
			console.log(xhr.responseText);
			$('#error').children('.alert-box').text(xhr.responseText['message']);
		});
		return false;
	});
});