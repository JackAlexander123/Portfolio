<?php 

function json_response($message = null, $code = 200){
  // clear the old headers
  header_remove();
  // set the actual code
  http_response_code($code);
  // set the header to make sure cache is forced
  header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
  // treat this as json
  header('Content-Type: application/json');
  $status = array(
    200 => '200 OK',
    400 => '400 Bad Request',
    422 => 'Unprocessable Entity',
    500 => '500 Internal Server Error'
    );
  // ok, validation error, or failure
  header('Status: '.$status[$code]);
  // return the encoded json
  return json_encode(array(
    'status' => $code < 300, // success or not?
    'message' => $message
    ));
}

$new_links = $_POST['new_links'];

$file_location = '\\\GRIFFIN\email_creatives_share/link-replacer/' . $_POST['file_name'] . '.html';

$message = 'Thank you for your submission!';

$html = file_get_contents($file_location);
//Create a new DOM document
$dom = new DOMDocument;

$split_hrefs = array();
$new_split_links = array();
$hrefcount = 0;
$linkcount = 0;

//Parse the HTML. The @ is used to suppress any parsing errors
//that will be thrown if the $html string isn't valid XHTML.
@$dom->loadHTML($html);

//Get all links. You could also use any other tag name here,
//like 'img' or 'table', to extract other tags.
$links = $dom->getElementsByTagName('a');

//Iterate over the extracted links and display their URLs
foreach ($links as $link){
    //Extract and show the "href" attribute.
    $href = $link->getAttribute('href');

    $html = str_replace($href, $href . 'link' . $hrefcount, $html);
    $before_html = $html;

    $new_href = $href . 'link' . $hrefcount;

    $split_hrefs[] = array(
      'href'  => $new_href,
    );
  $hrefcount++;
}

foreach ($split_hrefs as $single_href){

  $new_single_href = implode(" ", $single_href);
  $new_split_links[] = array(
    'new_href'  => $new_single_href,
  );  

}

foreach ($new_links as $single_new_foreach_link){

  $new_user_links[] = array(
    'new_href'  => $single_new_foreach_link,
  );  

}

$html = preg_replace('/(href="http:\/\/)/', 'href="', $html);
$html = preg_replace('/(href="https:\/\/)/', 'href="', $html);

$html = preg_replace("/(\/)/", "\/", $html);

$http = "http://";

foreach ($new_split_links as $single_new_href) {
  foreach ($new_user_links as $single_new_user_link) {
    $new_new_single_user_link = implode(" ", $single_new_user_link);
    $new_new_single_href = implode(" ", $single_new_href);

    $new_new_single_user_link_httpsless = preg_replace("/http.*\/\//", "", $new_new_single_user_link);
    $new_new_single_href_httpsless = preg_replace("/http.*\/\//", "", $new_new_single_href);

    $new_new_single_user_link_correct_slash = preg_replace("/(\/)/", "\/", $new_new_single_user_link_httpsless);
    $new_new_single_href_correct_slash = preg_replace("/(\/)/", "\/", $new_new_single_href_httpsless);

    $html = preg_replace("/(" . $new_new_single_href_correct_slash . ")/", $new_new_single_user_link_correct_slash , $html, 1);


  }
}
$html = str_replace('href="', 'href="http://', $html);

$html = preg_replace("/(link\d)/", "", $html);
// $html = preg_replace("/\\(\/)/", "/", $html);

$html = str_replace("\/", "/", $html);

file_put_contents($file_location, $html);

header('Content-Type: application/json');
echo json_response($new_user_links, 200);

?>