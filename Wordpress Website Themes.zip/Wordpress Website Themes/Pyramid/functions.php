<?php

function kryps_enqueue_scripts() {
  wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css');

	// wp_enqueue_script( 'easy-pie-js', get_stylesheet_directory_uri() . '/assets/js/jquery.easypiechart.min.js', array( 'jquery' ),null,true );

	// wp_enqueue_script( 'main-js', get_stylesheet_directory_uri() . '/assets/js/white-violet-0.1.0.min.js', array( 'jquery' ),null,true );
}
add_action( 'wp_enqueue_scripts', 'kryps_enqueue_scripts' );

function pp_setup_theme() {

  // include get_stylesheet_directory() . '/includes/post_types.php';
	include get_stylesheet_directory() . '/includes/social_icons.php';

	// include( $template_directory . '/includes/widgets.php' );

}
// add_action( 'after_setup_theme', 'pp_setup_theme' );

require_once get_stylesheet_directory() . '/includes/core.php';


/* Disable WordPress Admin Bar for all users but admins. */
// show_admin_bar(false);

?>