/*
 * Attaches the image uploader to the input field
 */
jQuery(document).ready(function($){

	$('.logo_upload_main').on('click', function(e) {
		console.log('before e.preventDefault()');
		e.preventDefault();
		console.log('after e.preventDefault()');

		var custom_uploader = wp.media({
			title: 'Upload a logo',
			button: {
					text: 'Upload'
			},
			multiple: false  // Set this to true to allow multiple files to be selected
		})
		.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			$('#logo_image_main').attr('src', attachment.url);
			$('#logo_url_main').val(attachment.url);
			$('#logo_id_main').val(attachment.id);
		})
		.open();

	});

	$('.logo_upload_sidebar').on('click', function(e) {
		console.log('before e.preventDefault()');
		e.preventDefault();
		console.log('after e.preventDefault()');

		var custom_uploader = wp.media({
			title: 'Upload a sidebar logo',
			button: {
					text: 'Upload'
			},
			multiple: false  // Set this to true to allow multiple files to be selected
		})
		.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			$('#logo_image_sidebar').attr('src', attachment.url);
			$('#logo_url_sidebar').val(attachment.url);
			$('#logo_id_sidebar').val(attachment.id);
		})
		.open();

	});

	$('.logo_upload_footer').on('click', function(e) {
		console.log('before e.preventDefault()');
		e.preventDefault();
		console.log('after e.preventDefault()');

		var custom_uploader = wp.media({
			title: 'Upload the footer logo',
			button: {
					text: 'Upload'
			},
			multiple: false  // Set this to true to allow multiple files to be selected
		})
		.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			$('#logo_image_footer').attr('src', attachment.url);
			$('#logo_url_footer').val(attachment.url);
			$('#logo_id_footer').val(attachment.id);
		})
		.open();

	});

	$('#favicon_upload').on('click', function(e) {
		console.log('before e.preventDefault()');
		e.preventDefault();
		console.log('after e.preventDefault()');

		var custom_uploader = wp.media({
			title: 'Upload the favicon logo',
			button: {
					text: 'Upload favicon'
			},
			multiple: false  // Set this to true to allow multiple files to be selected
		})
		.on('select', function() {
			var attachment = custom_uploader.state().get('selection').first().toJSON();
			$('#favicon_image').attr('src', attachment.url);
			$('#favicon_url').val(attachment.url);
			$('#favicon_id').val(attachment.id);
		})
		.open();

	});

});