jQuery(document).ready(function($) {
  $('#news-scroll').marquee({
  	duration: 20000
 	});
 	$('#services-scroll').marquee({
  	duration: 15000
 	});

 	$('#weddings-price-ceremony-only').on('click', function(e) {
		$('.weddings-price-ceremony-and-reception-block').removeClass('in');
		$('.weddings-price-ceremony-only-block').addClass('in');
		$('#weddings-price-ceremony-and-reception').removeClass('selected');
		$('#weddings-price-ceremony-only').addClass('selected');
 	});
 	$('#weddings-price-ceremony-and-reception').on('click', function(e) {
		$('.weddings-price-ceremony-only-block').removeClass('in');
		$('.weddings-price-ceremony-and-reception-block').addClass('in');
		$('#weddings-price-ceremony-only').removeClass('selected');
		$('#weddings-price-ceremony-and-reception').addClass('selected');
 	});

 	$('#hire-price-princes-theatre').on('click', function(e) {
		$('#essex-hall-block').removeClass('in');
		$('#princes-theatre-block').addClass('in');
		$('#hire-price-essex-hall').removeClass('selected');
		$('#hire-price-princes-theatre').addClass('selected');
 	});
 	$('#hire-price-essex-hall').on('click', function(e) {
		$('#princes-theatre-block').removeClass('in');
		$('#essex-hall-block').addClass('in');
		$('#hire-price-princes-theatre').removeClass('selected');
		$('#hire-price-essex-hall').addClass('selected');
 	});

 	if ( $( ".master-slider" ).length ) {
 	 
 	  var slider = new MasterSlider();
 	  	slider.setup('events-gallery' , {
 	      width:1080,    // slider standard width
 	      space:5,
 	      height:580
 	  	});
 	  	slider.control('arrows'); // here we've added arrow control to the slider.
 	}
});
