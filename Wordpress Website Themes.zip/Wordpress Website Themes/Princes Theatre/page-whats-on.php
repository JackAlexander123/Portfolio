<?php
get_header();

$is_page_builder_used = et_pb_is_pagebuilder_used( get_the_ID() );

?>

<div id="main-content">

	<div class="et_pb_section  et_pb_section_0 et_pb_specialty_fullwidth et_section_specialty">
		<div class="et_pb_row et_pb_row_1">
			<div class="et_pb_column et_pb_column_1_2 et_pb_column_0">
				<?php the_content(); ?>
			</div>
			<div class="et_pb_column et_pb_column_1_4 et_pb_column_0 brochure-column">
				<div class="form-wrapper">
					<p>Want to receive a brochure by post? Fill in our form and we will send it straight to your door.</p>
					<?php echo do_shortcode( '[contact-form-7 id="475" title="Whats on - Brochure Request"]' ); ?>
				</div>
				<div class="latest-brochure-wrapper">
					<span>CLICK HERE</span> TO DOWNLOAD OUR <u>LATEST BROCHURE</u><br>
					<i class="fa fa-cloud-download" aria-hidden="true"></i>
				</div>
			</div>
			<div class="et_pb_column et_pb_column_1_4 et_pb_column_0">
				<?php get_sidebar(); ?>
			</div>
		</div>
	</div>

</div> <!-- #main-content -->

<?php get_footer(); ?>