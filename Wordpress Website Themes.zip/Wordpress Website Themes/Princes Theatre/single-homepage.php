<?php
/*
Template Name: Homepage Template
*/
?>

<?php 
get_header();

$is_page_builder_used = et_pb_is_pagebuilder_used( get_the_ID() ); ?>

<div id="main-content">

<div class="et_pb_section et_pb_section_0 et_section_regular" id="page-intro">
	<div class="et_pb_row et_pb_row_1">
		<div class="et_pb_column et_pb_column_4_4 et_pb_column_0">
			<div class="master-slider ms-skin-default" id="events-gallery">

			 	<!-- <div class="ms-slide">
		      <img src="http://placehold.it/350x300?text=6">
			 		<!-- <div class="gallery-caption-div">TEST</div> -->
			 		<!-- <div class="ms-layer ms-caption" style="top:10px; left:30px;">
 		        <h3>Wed 15th Sep - Fri 17th Sep 2015</h3>
 		        <h2>Jersey Boys</h2>
 		        <a href="#" class="et_pb_more_button et_pb_button secondary">More Information</a><a href="#" class="et_pb_button primary">Book Now</a>
	 		    </div> -->
			 	<!-- </div> -->
				
				

				<?php 

				$limit = 'limit';
				$scope = 'scope';
				$format = 'format';

				$args[$format] = '<div class="ms-slide"><img src="#_EVENTIMAGEURL"><div class="ms-layer ms-caption"><h3>#_EVENTDATES at #_EVENTTIMES</h3><h2>#_EVENTNAME</h2><a href="#_EVENTURL" class="et_pb_more_button et_pb_button secondary">More Information</a><a href="#" class="et_pb_button primary">Book Now</a></div></div>';

				$args[$limit] = '10';
				$args[$scope] = 'future';

				echo EM_Events::output( $args );

				 ?>

			</div>
		</div>
	</div>
</div>

<?php if ( ! $is_page_builder_used ) : ?>

	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area">

<?php endif; ?>

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<?php if ( ! $is_page_builder_used ) : ?>

					<h1 class="main_title"><?php the_title(); ?></h1>
				<?php
					$thumb = '';

					$width = (int) apply_filters( 'et_pb_index_blog_image_width', 1080 );

					$height = (int) apply_filters( 'et_pb_index_blog_image_height', 675 );
					$classtext = 'et_featured_image';
					$titletext = get_the_title();
					$thumbnail = get_thumbnail( $width, $height, $classtext, $titletext, $titletext, false, 'Blogimage' );
					$thumb = $thumbnail["thumb"];

					if ( 'on' === et_get_option( 'divi_page_thumbnails', 'false' ) && '' !== $thumb )
						print_thumbnail( $thumb, $thumbnail["use_timthumb"], $titletext, $width, $height );
				?>

				<?php endif; ?>

					<div class="entry-content">
					<?php
						the_content();

						if ( ! $is_page_builder_used )
							wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'Divi' ), 'after' => '</div>' ) );
					?>
					</div> <!-- .entry-content -->

				<?php
					if ( ! $is_page_builder_used && comments_open() && 'on' === et_get_option( 'divi_show_pagescomments', 'false' ) ) comments_template( '', true );
				?>

				</article> <!-- .et_pb_post -->

			<?php endwhile; ?>

<?php if ( ! $is_page_builder_used ) : ?>

			</div> <!-- #left-area -->

			<?php get_sidebar(); ?>
		</div> <!-- #content-area -->
	</div> <!-- .container -->

<?php endif; ?>

</div> <!-- #main-content -->

<?php get_footer(); ?>