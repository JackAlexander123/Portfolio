<?php

function pp_setup_theme() {

	include( $template_directory . '/includes/widgets.php' );
	
}
add_action( 'after_setup_theme', 'pp_setup_theme' );

function enqueue_pp_scripts() {

	wp_enqueue_script( 'jquery', 'https://code.jquery.com/jquery-2.2.0.min.js' );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css');
	wp_enqueue_script( 'jquery-marquee', '//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js' );
	wp_enqueue_script( 'pp-scripts', get_stylesheet_directory_uri() . '/assets/js/princes-theatre-0.1.0.min.js', array( 'jquery' ),null,true );

	wp_enqueue_style( 'princes-masterslider-style', get_stylesheet_directory_uri() . '/assets/css/masterslider.main.min.css' );
	wp_enqueue_style( 'princes-masterslider-default-style', get_stylesheet_directory_uri() . '/assets/css/ms-skin-sample.css' );
	wp_enqueue_script( 'princes-masterslider-core', get_stylesheet_directory_uri() . '/assets/js/masterslider.min.js', array( 'jquery' ),null,true );

}
add_action( 'wp_enqueue_scripts', 'enqueue_pp_scripts');


//  Disable WordPress Admin Bar for all users but admins. 
// show_admin_bar(false);

// Useful functions
function is_tree($pid){
	global $post;
	if (is_page()&&($post->post_parent==$pid||is_page($pid))) {
		return true;
	} else {
		return false;
	}
}

function theme_options_scripts($hook) {
	if (is_admin()) {
		wp_enqueue_style( 'princes-theatre-theme-options-css', get_stylesheet_directory_uri() . '/assets/css/admin.css', array(), '', 'all' );
		wp_enqueue_script( 'princes-theatre-theme-options-admin-js', get_stylesheet_directory_uri() . '/assets/js/admin.js', array( 'jquery' ), '1.0.0', true );
		if (function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}else{
			wp_enqueue_style( 'thickbox' );
			wp_enqueue_script( 'media-upload' );
			wp_enqueue_script( 'thickbox' );
		}
	}
}
add_action('admin_enqueue_scripts', 'theme_options_scripts');

// function theme_options_scripts(){
// 	wp_enqueue_script( 'gnd-admin-js', get_template_directory_uri() . '/assets/js/admin.js', array( 'jquery' ), '1.0.0', true );
// }

function add_theme_menu_item(){
	add_menu_page("Theme Panel", "Theme Panel", "manage_options", "theme-options", "theme_settings_page", null, 99);
}

add_action("admin_menu", "add_theme_menu_item");


function theme_settings_page(){
    ?>
	    <div class="wrap princes-theatre-theme-options">
	    <h1>Theme Panel</h1>
	    <form method="post" action="options.php">
	        <?php
	            settings_fields("section");
	            do_settings_sections("theme-options");      
	            submit_button(); 
	        ?>          
	    </form>
		</div>
	<?php
}

function display_twitter_element(){
?>
	<input type="text" name="twitter_url" id="twitter_url" value="<?php echo get_option('twitter_url'); ?>" />
<?php
}

function display_facebook_element(){
?>
	<input type="text" name="facebook_url" id="facebook_url" value="<?php echo get_option('facebook_url'); ?>" />
<?php
}

function display_youtube_element(){
?>
	<input type="text" name="youtube_url" id="youtube_url" value="<?php echo get_option('youtube_url'); ?>" />
<?php
}

function display_tripadvisor_element(){
?>
	<input type="text" name="tripadvisor_url" id="tripadvisor_url" value="<?php echo get_option('tripadvisor_url'); ?>" />
<?php
}

function display_contact_email_element(){
?>
	<input type="email" name="contact_email" id="contact_email" value="<?php echo get_option('contact_email'); ?>" />
<?php
}

function display_contact_number_element(){
?>
	<input type="tel" name="contact_number" id="contact_number" value="<?php echo get_option('contact_number'); ?>" />
<?php
}

function display_mailchimp_api_element(){
	?>
	<input type="text" name="mailchimp_api" id="mailchimp_api" value="<?php echo get_option('mailchimp_api'); ?>" />
<?php
}

function display_header_scroller_element(){
	?>
	<input type="text" name="header_scroller_text" id="header_scroller_text" value="<?php echo get_option('header_scroller_text'); ?>" />
<?php
}

function display_theme_panel_fields(){
	add_settings_section("section", "All Settings", null, "theme-options");
	
	add_settings_field("twitter_url", "Twitter Profile URL", "display_twitter_element", "theme-options", "section");
	add_settings_field("facebook_url", "Facebook Profile URL", "display_facebook_element", "theme-options", "section");
	add_settings_field("youtube_url", "Youtube Profile URL", "display_youtube_element", "theme-options", "section");
	add_settings_field("tripadvisor_url", "Trip Advisor Profile URL", "display_tripadvisor_element", "theme-options", "section");

	add_settings_field("contact_email", "Contact email", "display_contact_email_element", "theme-options", "section");
	add_settings_field("contact_number", "Contact number", "display_contact_number_element", "theme-options", "section");

	add_settings_field("mailchimp_api", "Mailchimp API Key", "display_mailchimp_api_element", "theme-options", "section");
	add_settings_field("header_scroller_text", "Header scroller text", "display_header_scroller_element", "theme-options", "section");

	register_setting("section", "twitter_url");
	register_setting("section", "facebook_url");
	register_setting("section", "youtube_url");
	register_setting("section", "tripadvisor_url");
	register_setting("section", "contact_email");
	register_setting("section", "contact_number");
	register_setting("section", "mailchimp_api");
	register_setting("section", "header_scroller_text");
}

add_action("admin_init", "display_theme_panel_fields");

function wpdocs_register_my_custom_menu_page() {
    add_menu_page("Theme Panel", "Theme Panel", "manage_options", "theme-options", "theme_settings_page", null, 99);
}
add_action( 'admin_menu', 'wpdocs_register_my_custom_menu_page' );

?>