<?php

function kryps_enqueue_scripts() {
  wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css');

	wp_enqueue_script( 'easy-pie-js', get_stylesheet_directory_uri() . '/assets/js/jquery.easypiechart.min.js', array( 'jquery' ),null,true );

	wp_enqueue_script( 'main-js', get_stylesheet_directory_uri() . '/assets/js/KJT-0.1.0.min.js', array( 'jquery' ),null,true );

	if ( is_singular( 'services' )) {
		$plugins_path = plugins_url();

		wp_enqueue_style( 'kjt-masterslider-style', $plugins_path . '/master-slider/public/assets/css/masterslider.main.min.css' );
		wp_enqueue_style( 'kjt-masterslider-default-style', $plugins_path . '/master-slider/public/assets/css/ms-skin-sample.css' );
		wp_enqueue_script( 'kjt-masterslider-core', $plugins_path . '/master-slider/public/assets/js/masterslider.min.js', array( 'jquery', 'jquery-easing' ), '1.0.0', true );
	}
}
add_action( 'wp_enqueue_scripts', 'kryps_enqueue_scripts' );

function pp_setup_theme() {

	include get_stylesheet_directory() . '/includes/post_types.php';

	// include( $template_directory . '/includes/widgets.php' );

}
add_action( 'after_setup_theme', 'pp_setup_theme' );

function custom_post_type_sub_page_urls(){
  add_rewrite_tag('%custom_post_type_sub_page%', '([^&]+)');
  add_rewrite_rule(
    'services/([^/]*)/([^/]*)',
    'index.php?services=$matches[1]&custom_post_type_sub_page=$matches[2]',
    'top'
  );
  flush_rewrite_rules();
}
add_action('init', 'custom_post_type_sub_page_urls');

require_once get_stylesheet_directory() . '/includes/core.php';


/* Disable WordPress Admin Bar for all users but admins. */
// show_admin_bar(false);


function doCustomModules(){
 if(class_exists("ET_Builder_Module")){
    include get_stylesheet_directory() . '/includes/custom_divi_modules.php';
 }
}

function prepareCustomModule(){
 global $pagenow;

 $is_admin = is_admin();
 $action_hook = $is_admin ? 'wp_loaded' : 'wp';
 $required_admin_pages = array( 'edit.php', 'post.php', 'post-new.php', 'admin.php', 'customize.php', 'edit-tags.php', 'admin-ajax.php', 'export.php' ); // list of admin pages where we need to load builder files
 $specific_filter_pages = array( 'edit.php', 'admin.php', 'edit-tags.php' ); // list of admin pages where we need more specific filtering
 $is_edit_library_page = 'edit.php' === $pagenow && isset( $_GET['post_type'] ) && 'et_pb_layout' === $_GET['post_type'];
    $is_role_editor_page = 'admin.php' === $pagenow && isset( $_GET['page'] ) && 'et_divi_role_editor' === $_GET['page'];
    $is_import_page = 'admin.php' === $pagenow && isset( $_GET['import'] ) && 'wordpress' === $_GET['import']; // Page Builder files should be loaded on import page as well to register the et_pb_layout post type properly
    $is_edit_layout_category_page = 'edit-tags.php' === $pagenow && isset( $_GET['taxonomy'] ) && 'layout_category' === $_GET['taxonomy'];

 if ( ! $is_admin || ( $is_admin && in_array( $pagenow, $required_admin_pages ) && ( ! in_array( $pagenow, $specific_filter_pages ) || $is_edit_library_page || $is_role_editor_page || $is_edit_layout_category_page || $is_import_page ) ) ) {
    add_action($action_hook, 'doCustomModules', 9789);
 }
}
prepareCustomModule();

?>