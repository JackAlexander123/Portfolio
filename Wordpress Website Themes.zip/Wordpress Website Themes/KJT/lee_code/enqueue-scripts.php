<?php
function site_scripts() {
	global $wp_styles; // Call global $wp_styles variable to add conditional wrapper around ie stylesheet the WordPress way
	global $post_type;

	// Load What-Input files in footer
	wp_enqueue_script( 'what-input', get_template_directory_uri() . '/vendor/what-input/what-input.min.js', array(), '', true );
	
	// Adding Foundation scripts file in the footer
	wp_enqueue_script( 'foundation-js', get_template_directory_uri() . '/assets/js/foundation.js', array( 'jquery' ), '6.2', true );
	
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/vendor/owl.carousel/dist/owl.carousel.min.js', array( 'jquery' ), '2.0', true );

	// Adding Motion UI file in the footer
	// wp_enqueue_script( 'motion-ui-js', get_template_directory_uri() . '/vendor/motion-ui/dist/motion-ui.min.js', array( 'jquery' ), '', true );

	// Adding scripts file in the footer
	wp_enqueue_script( 'site-js', get_template_directory_uri() . '/assets/js/scripts.js', array( 'jquery' ), '', true );
	wp_localize_script( 'site-js', 'gnd_custom', array(
		'ajaxurl'				=> admin_url( 'admin-ajax.php' ),
		'is_home'				=> is_front_page(),
		'page_id'				=> get_the_ID()
	) );
	
	// Register main stylesheet
	wp_enqueue_style( 'site-css', get_template_directory_uri() . '/assets/css/style.css', array(), '', 'all' );

	// Comment reply script for threaded comments
	if ( is_singular() AND comments_open() AND (get_option('thread_comments') == 1)) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_front_page() || is_singular( 'portfolio' ) ) {
		wp_enqueue_script( 'slick-js', get_template_directory_uri() . '/vendor/slick-carousel/slick/slick.min.js', array( 'jquery' ), '1.5.9', true );
	}

	// Set and enqueue Google Fonts
	$query_args = array(
		'family'    => 'Fira+Sans:400,700italic,700,500,400italic|Source+Sans+Pro:400,700italic,700,500,400italic'
	);
	wp_enqueue_style( 'google-fonts', add_query_arg( $query_args, '//fonts.googleapis.com/css' ), array(), null );
}
add_action('wp_enqueue_scripts', 'site_scripts', 999);