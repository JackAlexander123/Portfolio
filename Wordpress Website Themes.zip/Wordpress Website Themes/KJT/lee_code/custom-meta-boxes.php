<?php
function gnd_meta_box_enqueues($hook) {
	global $post_type;
	if ( 'post.php' == $hook || 'post-new.php' == $hook ) {
		if ( 'portfolio' == $post_type ){
			wp_enqueue_script('gallery-metabox', get_template_directory_uri() . '/assets/js/meta-box-image.js', array('jquery', 'jquery-ui-sortable'));
			wp_enqueue_style('gallery-metabox', get_template_directory_uri() . '/assets/css/admin.css');
		}
	}
}
add_action('admin_enqueue_scripts', 'gnd_meta_box_enqueues');
function gnd_meta_boxes(){
	add_meta_box( 'gnd_team_side_meta', __( 'Team Member Info', 'gnd' ), 'gnd_team_side_meta_cb', 'team', 'side', 'high' );
	add_meta_box( 'gnd_project_main_meta', __( 'Project Configuration', 'gnd' ), 'gnd_project_main_meta_cb', 'portfolio', 'normal', 'high' );
	// add_meta_box( 'villas_main_meta', __( 'Villa Settings', 'pc-perfect' ), 'villas_main_meta_callback', 'villas', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'gnd_meta_boxes' );

/**
* Outputs the content of the team side meta box
*/
function gnd_team_side_meta_cb( $post ){ ?>
	<?php
		wp_nonce_field( basename( __FILE__ ), 'gnd_team_side_nonce' );
		$team_member_stored_meta = get_post_meta( $post->ID );
	?>

	<p class="team-member-row">
		<label for="meta-team-position" class="team-meta-title"><?php _e( 'Role/Position', 'gnd' )?></label>
		<input type="text" name="meta-team-position" id="meta-team-position" value="<?php if ( isset ( $team_member_stored_meta['meta-team-position'] ) ) echo $team_member_stored_meta['meta-team-position'][0]; ?>" />
	</p>

<?php
}

/**
 * Saves the custom team meta input
 */
function gnd_team_meta_save( $post_id ) {
 
	// Checks save status
	$is_autosave = wp_is_post_autosave( $post_id );
	$is_revision = wp_is_post_revision( $post_id );
	$is_valid_nonce = ( isset( $_POST[ 'gnd_team_side_nonce' ] ) && wp_verify_nonce( $_POST[ 'gnd_team_side_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
 
	// Exits script depending on save status
	if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
		return;
	}
 
	// Checks for input and sanitizes/saves if needed
	if( isset( $_POST[ 'meta-team-position' ] ) ) {
		update_post_meta( $post_id, 'meta-team-position', sanitize_text_field( $_POST[ 'meta-team-position' ] ) );
	}

}
add_action( 'save_post', 'gnd_team_meta_save' );

/**
* Outputs the content of the team side meta box
*/
function gnd_project_main_meta_cb( $post ){
	wp_nonce_field( basename( __FILE__ ), 'gnd_project_main_nonce' );
	$project_stored_meta = get_post_meta( $post->ID );
	$gallery_ids = get_post_meta( $post->ID, 'meta-project-gallery-id', true );
	$project_skills = get_post_meta( $post->ID, 'meta-project-skills', true );
?>

	<div class="portfolio-row">
		<div id="gallery-metabox" class="portfolio-col">
			<label for="meta-project-gallery-id" class="gallery-meta-title"><?php _e( 'Project Gallery', 'gnd' ); ?></label>
			<button class="gallery-add button" type="button" data-uploader-title="Add image(s) to project" data-uploader-button-text="Add image(s)">Add image(s)</button>
			<?php if ($gallery_ids) : ?>
			<ul id="gallery-metabox-list">
				<?php foreach ($gallery_ids as $gallery_img => $data) : $image = wp_get_attachment_image_src($data['id']); ?>
			  <li>
			    <input type="hidden" name="meta-project-gallery-id[<?php echo $gallery_img; ?>][id]" value="<?php echo $data['id']; ?>">
			    <img class="image-preview" src="<?php echo $image[0]; ?>">
			    <input type="text" name="meta-project-gallery-id[<?php echo $gallery_img; ?>][caption]" value="<?php echo $data['caption']; ?>">
			    <button class="change-image button button-small" type="button" data-uploader-title="Change image" data-uploader-button-text="Change image">Change image</button><br>
			    <small><button class="remove-image button button-small" type="button">Remove image</button></small>
			  </li>
			<?php endforeach; ?>
			</ul>
			<?php endif; ?>
		</div>
	</div>

<?php
}

/**
 * Saves the custom team meta input
 */
function gnd_project_meta_save( $post_id ) {
 
	// Checks save status
	$is_autosave = wp_is_post_autosave( $post_id );
	$is_revision = wp_is_post_revision( $post_id );
	$is_valid_nonce = ( isset( $_POST[ 'gnd_project_main_nonce' ] ) && wp_verify_nonce( $_POST[ 'gnd_project_main_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

	// Exits script depending on save status
	if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
		return;
	}
 
	// Checks for input and sanitizes/saves if needed
	if( isset( $_POST[ 'meta-project-gallery-id' ] ) ) {
		update_post_meta( $post_id, 'meta-project-gallery-id', $_POST[ 'meta-project-gallery-id' ] );
	} else {
		delete_post_meta( $post_id, 'meta-project-gallery-id' );
	}

}
add_action( 'save_post', 'gnd_project_meta_save' );

?>