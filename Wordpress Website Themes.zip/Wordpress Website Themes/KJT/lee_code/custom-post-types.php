<?php
/* joints Custom Post Type Example
This page walks you through creating 
a custom post type and taxonomies. You
can edit this one or copy the following code 
to create another one. 

I put this in a separate file so as to 
keep it organized. I find it easier to edit
and change things if they are concentrated
in their own file.

*/


// let's create the function for the custom type
function gnd_post_types() {

	// Intros Post Type
	register_post_type( 'intros',
		array('labels' => array(
			'name' => __('Intros', 'jointswp'),
			'singular_name' => __('Intro', 'jointswp'),
			'all_items' => __('All Intros', 'jointswp'),
			'add_new' => __('Add New', 'jointswp'),
			'add_new_item' => __('Add New Intro', 'jointswp'),
			'edit' => __( 'Edit', 'jointswp' ),
			'edit_item' => __('Edit Intro', 'jointswp'),
			'new_item' => __('New Intro', 'jointswp'),
			'view_item' => __('View Intro', 'jointswp'),
			'search_items' => __('Search Intros', 'jointswp'),
			'not_found' =>  __('Nothing found in the Database.', 'jointswp'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointswp'),
			'parent_item_colon' => ''
			),
			'description' => __( 'These are the intros used on the homepage', 'jointswp' ),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 4, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-admin-comments', /* the icon for the custom post type menu. uses built-in dashicons (CSS class name) */
			'rewrite'	=> array( 'slug' => 'intros', 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => 'intros', /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'revisions',)
	 	)
	);

 	// Products Post Type
	register_post_type( 'products',
		array('labels' => array(
			'name' => __('Products', 'jointswp'),
			'singular_name' => __('Product', 'jointswp'),
			'all_items' => __('All Products', 'jointswp'),
			'add_new' => __('Add New', 'jointswp'),
			'add_new_item' => __('Add New Product', 'jointswp'),
			'edit' => __( 'Edit', 'jointswp' ),
			'edit_item' => __('Edit Product', 'jointswp'),
			'new_item' => __('New Product', 'jointswp'),
			'view_item' => __('View Product', 'jointswp'),
			'search_items' => __('Search Products', 'jointswp'),
			'not_found' =>  __('Nothing found in the Database.', 'jointswp'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointswp'),
			'parent_item_colon' => ''
			),
			'description' => __( 'These are the products we offer', 'jointswp' ),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 4, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-cart', /* the icon for the custom post type menu. uses built-in dashicons (CSS class name) */
			'rewrite'	=> array( 'slug' => 'products', 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => 'products', /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky')
	 	) /* end of options */
	); /* end of register post type */

	// Packages Post Type
	register_post_type( 'packages',
		array('labels' => array(
			'name' => __('Packages', 'jointswp'),
			'singular_name' => __('Package', 'jointswp'),
			'all_items' => __('All Packages', 'jointswp'),
			'add_new' => __('Add New', 'jointswp'),
			'add_new_item' => __('Add New Package', 'jointswp'),
			'edit' => __( 'Edit', 'jointswp' ),
			'edit_item' => __('Edit Package', 'jointswp'),
			'new_item' => __('New Package', 'jointswp'),
			'view_item' => __('View Package', 'jointswp'),
			'search_items' => __('Search Packages', 'jointswp'),
			'not_found' =>  __('Nothing found in the Database.', 'jointswp'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointswp'),
			'parent_item_colon' => ''
			),
			'description' => __( 'These are the packages we offer', 'jointswp' ),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 4, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-cart', /* the icon for the custom post type menu. uses built-in dashicons (CSS class name) */
			'rewrite'	=> array( 'slug' => 'packages', 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => 'packages', /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky')
	 	)
	);

	// Portfolio Post Type
	register_post_type( 'portfolio',
		array('labels' => array(
			'name' => __('Portfolio', 'jointswp'),
			'singular_name' => __('Project', 'jointswp'),
			'all_items' => __('All Projects', 'jointswp'),
			'add_new' => __('Add New', 'jointswp'),
			'add_new_item' => __('Add New Project', 'jointswp'),
			'edit' => __( 'Edit', 'jointswp' ),
			'edit_item' => __('Edit Project', 'jointswp'),
			'new_item' => __('New Project', 'jointswp'),
			'view_item' => __('View Project', 'jointswp'),
			'search_items' => __('Search Projects', 'jointswp'),
			'not_found' =>  __('Nothing found in the Database.', 'jointswp'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointswp'),
			'parent_item_colon' => ''
			),
			'description' => __( 'These are the projects we have done', 'jointswp' ),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 4, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-images-alt', /* the icon for the custom post type menu. uses built-in dashicons (CSS class name) */
			'rewrite'	=> array( 'slug' => 'portfolio', 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => 'portfolio', /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky')
	 	) /* end of options */
	); /* end of register post type */

	// Team Post Type
	register_post_type( 'team',
		array('labels' => array(
			'name' => __('Team Members', 'jointswp'),
			'singular_name' => __('Member', 'jointswp'),
			'all_items' => __('All Members', 'jointswp'),
			'add_new' => __('Add New', 'jointswp'),
			'add_new_item' => __('Add New Member', 'jointswp'),
			'edit' => __( 'Edit', 'jointswp' ),
			'edit_item' => __('Edit Member', 'jointswp'),
			'new_item' => __('New Member', 'jointswp'),
			'view_item' => __('View Member', 'jointswp'),
			'search_items' => __('Search Members', 'jointswp'),
			'not_found' =>  __('Nothing found in the Database.', 'jointswp'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointswp'),
			'parent_item_colon' => ''
			),
			'description' => __( 'These are the team members of Ginger Nut Design', 'jointswp' ),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 4, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-groups', /* the icon for the custom post type menu. uses built-in dashicons (CSS class name) */
			'rewrite'	=> array( 'slug' => 'team', 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => 'team', /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky')
	 	)
	);

	// Testimonials Post Type
	register_post_type( 'testimonials',
		array('labels' => array(
			'name' => __('Testimonials', 'jointswp'),
			'singular_name' => __('Testimonial', 'jointswp'),
			'all_items' => __('All Testimonials', 'jointswp'),
			'add_new' => __('Add New', 'jointswp'),
			'add_new_item' => __('Add New Testimonial', 'jointswp'),
			'edit' => __( 'Edit', 'jointswp' ),
			'edit_item' => __('Edit Testimonial', 'jointswp'),
			'new_item' => __('New Testimonial', 'jointswp'),
			'view_item' => __('View Testimonial', 'jointswp'),
			'search_items' => __('Search Packages', 'jointswp'),
			'not_found' =>  __('Nothing found in the Database.', 'jointswp'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointswp'),
			'parent_item_colon' => ''
			),
			'description' => __( 'These are the testimonials from our clients', 'jointswp' ),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 4, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-format-quote', /* the icon for the custom post type menu. uses built-in dashicons (CSS class name) */
			'rewrite'	=> array( 'slug' => 'testimonials', 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => 'testimonials', /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => false,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky')
	 	)
	);
	
	/* this adds your post categories to your custom post type */
	// register_taxonomy_for_object_type('category', 'portfolio');
	/* this adds your post tags to your custom post type */
	// register_taxonomy_for_object_type('post_tag', 'portfolio');
	
} 

	// adding the function to the Wordpress init
	add_action( 'init', 'gnd_post_types');
	
	/*
	for more information on taxonomies, go here:
	http://codex.wordpress.org/Function_Reference/register_taxonomy
	*/
	
	// now let's add custom categories (these act like categories)
    register_taxonomy( 'project-types', 
    	array('portfolio'), /* if you change the name of register_post_type( 'custom_type', then you have to change this */
    	array('hierarchical' => true,     /* if this is true, it acts like categories */             
    		'labels' => array(
    			'name' => __( 'Project Types', 'jointswp' ), /* name of the custom taxonomy */
    			'singular_name' => __( 'Project Type', 'jointswp' ), /* single taxonomy name */
    			'search_items' =>  __( 'Search Project Types', 'jointswp' ), /* search title for taxomony */
    			'all_items' => __( 'All Project Types', 'jointswp' ), /* all title for taxonomies */
    			'parent_item' => __( 'Parent Project Type', 'jointswp' ), /* parent title for taxonomy */
    			'parent_item_colon' => __( 'Parent Project Type:', 'jointswp' ), /* parent taxonomy title */
    			'edit_item' => __( 'Edit Project Type', 'jointswp' ), /* edit custom taxonomy title */
    			'update_item' => __( 'Update Project Type', 'jointswp' ), /* update title for taxonomy */
    			'add_new_item' => __( 'Add New Project Type', 'jointswp' ), /* add new title for taxonomy */
    			'new_item_name' => __( 'New Project Type Name Name', 'jointswp' ) /* name title for taxonomy */
    		),
    		'show_admin_column' => true, 
    		'show_ui' => true,
    		'query_var' => true,
    		'rewrite' => array( 'slug' => 'project-type' ),
    	)
    );   
    
	// now let's add custom tags (these act like categories)
    register_taxonomy( 'project-skills', 
    	array('portfolio'), /* if you change the name of register_post_type( 'custom_type', then you have to change this */
    	array('hierarchical' => false,    /* if this is false, it acts like tags */                
    		'labels' => array(
    			'name' => __( 'Project Skills', 'jointswp' ), /* name of the custom taxonomy */
    			'singular_name' => __( 'Project Skill', 'jointswp' ), /* single taxonomy name */
    			'search_items' =>  __( 'Search Project Skills', 'jointswp' ), /* search title for taxomony */
    			'all_items' => __( 'All Project Skills', 'jointswp' ), /* all title for taxonomies */
    			'parent_item' => __( 'Parent Project Skill', 'jointswp' ), /* parent title for taxonomy */
    			'parent_item_colon' => __( 'Parent Project Skill:', 'jointswp' ), /* parent taxonomy title */
    			'edit_item' => __( 'Edit Project Skill', 'jointswp' ), /* edit custom taxonomy title */
    			'update_item' => __( 'Update Project Skills', 'jointswp' ), /* update title for taxonomy */
    			'add_new_item' => __( 'Add New Project Skill', 'jointswp' ), /* add new title for taxonomy */
    			'new_item_name' => __( 'New Project Skill Name', 'jointswp' ) /* name title for taxonomy */
    		),
    		'show_admin_column' => true,
    		'show_ui' => true,
    		'query_var' => true,
    	)
    ); 
    
    /*
    	looking for custom meta boxes?
    	check out this fantastic tool:
    	https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
    */

// Strips archive prefixes
add_filter( 'get_the_archive_title', function( $title ) {

	if ( is_post_type_archive() ) {
		if ( is_post_type_archive('portfolio') ) {
			$title = sprintf( __( 'Our %s' ), post_type_archive_title( '', false ) );
		}else{
			$title = sprintf( __( 'Archives: %s' ), post_type_archive_title( '', false ) );
		}
	} elseif ( is_tax( 'project-types' ) ) {
		$title = _x( '', 'post format archive title' );
	} elseif ( is_tax( 'project-skills' ) ) {
		$title = _x( '#<span class="skills-title">' . get_queried_object()->name . '</span>', 'post format archive title' );
	} else {
		$title = __( 'Archives' );
	}

	return $title;

});