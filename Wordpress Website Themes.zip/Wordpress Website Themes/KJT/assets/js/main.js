jQuery(document).ready(function($) {

	var $theCounter = $('.ndr_counter');
	$('.percentage').easyPieChart({
		barColor: '#ffffff',
		trackColor: '#601f2c',
		size: 250,
		scaleColor: false
  });
	$('.percentage').easyPieChart({
		barColor: '#ffffff',
		trackColor: '#601f2c',
		size: 200,
		scaleColor: false
	});

	if ( $( ".master-slider" ).length ) {
	 
	  var slider = new MasterSlider();
	  	slider.setup('services-gallery' , {
	      width:1040,    // slider standard width
	      space:5,
	      autoHeight:true,
	      view: "mask",
	      layout: "boxed"
	  	});
	  	// slider.control('bullets');
	  	slider.control('thumblist',{
	  		autohide: false, 
	  		align: "bottom"
	  	});
	 
	}

});